package com.gestordemandas.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private WebView webView;
    private LocationManager locationManager;
    private LocationListener listener;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GPSBridge(), "AndroidGPS");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class GPSBridge {
        @JavascriptInterface public void getLocation() {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                return;
            }
            startLocation();
        }
    }

    private void startLocation() {
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            runJS("window.gpsNativeStatus('⚠️ Ative a Localização/GPS do celular e tente novamente.');");
        }

        if (listener != null) {
            try { locationManager.removeUpdates(listener); } catch (Exception ignored) {}
        }

        listener = new LocationListener() {
            @Override public void onLocationChanged(Location location) {
                String js = String.format(java.util.Locale.US,
                    "window.gpsNativeSuccess(%f,%f,%f);",
                    location.getLatitude(), location.getLongitude(),
                    location.hasAccuracy() ? location.getAccuracy() : 0.0f);
                runJS(js);
                try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
                listener = null;
            }
        };

        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, listener);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 1f, listener);
            }
            Location last = null;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null && System.currentTimeMillis() - last.getTime() < 120000) {
                listener.onLocationChanged(last);
            }
            runJS("window.gpsNativeStatus('📡 Procurando localização... mantenha o celular com a localização ativada.');");
        } catch (SecurityException e) {
            runJS("window.gpsNativeStatus('❌ Permissão de localização não concedida.');");
        }
    }

    private void runJS(final String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST) {
            boolean ok = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { ok = true; break; }
            if (ok) startLocation();
            else runJS("window.gpsNativeStatus('❌ Permissão de localização negada. Vá em Configurações > Apps > Gestor de Demandas > Permissões > Localização.');");
        }
    }

    @Override protected void onDestroy() {
        if (listener != null) try { locationManager.removeUpdates(listener); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
